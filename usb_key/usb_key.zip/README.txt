Content of the USB Key :
- APDL : source of the APDL compiler
- APDL-Handler : source of the APDL Serial Handler
- articles : articles read and cite in this project
- case-study-from-scratch-http : case study on sending InfluxDB data with an Arduino through HTTP
- case-study-from-scratch-mqtt : case study on sending InfluxDB data with an Arduino through MQTT
- SimpleCalculatorDSL : implementation of a simple calculator DSL as an example for chapter 2 of the thesis
- thesis : latex's source of the thesis
- Licence : license of the project
- TM-Julmy-2017.pdf : printed version of the thesis
